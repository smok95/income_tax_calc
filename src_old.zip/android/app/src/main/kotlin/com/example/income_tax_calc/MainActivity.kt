package com.smok95.income_tax_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
